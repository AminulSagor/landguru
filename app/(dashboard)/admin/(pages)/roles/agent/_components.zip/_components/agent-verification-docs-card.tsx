import Card from "@/components/cards/card";
import { AgentDetails } from "@/types/admin/agent-list/details/[id]/agent-details.types";
import { BadgeCheck, FileText, ShieldCheck } from "lucide-react";

export default function AgentVerificationDocsCard({
  agent,
}: {
  agent: AgentDetails;
}) {
  const docs = agent?.verificationDocuments ?? [];

  return (
    <Card>
      <div className="flex items-center gap-2">
        <BadgeCheck size={18} className="text-primary" />
        <p className="font-semibold text-black">Verification Documents</p>
      </div>

      <div className="mt-4 space-y-3">
        {docs.length > 0 ? (
          docs.map((doc, index) => {
            const Icon = doc?.verified ? ShieldCheck : FileText;

            return (
              <div
                key={`${doc.title ?? "document"}-${index}`}
                className="flex items-center justify-between rounded-lg border border-gray/10 bg-white px-4 py-3"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary">
                    <Icon size={18} className="text-primary" />
                  </div>

                  <div>
                    <p className="text-sm font-semibold text-black">
                      {doc.title ?? "-"}
                    </p>
                    <p className="mt-1 text-xs text-gray">{doc.meta ?? "-"}</p>
                  </div>
                </div>

                <span
                  className={`rounded-full px-3 py-1 text-xs font-semibold ${
                    doc?.verified
                      ? "bg-green/10 text-green"
                      : "bg-gray-100 text-gray-500"
                  }`}
                >
                  {doc?.verified ? "Verified" : "Unverified"}
                </span>
              </div>
            );
          })
        ) : (
          <div className="rounded-lg border border-gray/10 bg-secondary px-4 py-3 text-sm text-gray">
            No verification documents available
          </div>
        )}
      </div>
    </Card>
  );
}