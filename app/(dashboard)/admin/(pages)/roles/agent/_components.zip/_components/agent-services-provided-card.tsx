import Card from "@/components/cards/card";
import { AgentDetails } from "@/types/admin/agent-list/details/[id]/agent-details.types";
import { Wrench } from "lucide-react";

const formatPrice = (value?: string | number | null) => {
  if (value === null || value === undefined || value === "") {
    return "-";
  }

  return String(value);
};

export default function AgentServicesProvidedCard({
  agent,
}: {
  agent: AgentDetails;
}) {
  const services = agent?.services ?? [];

  return (
    <Card>
      <div className="flex items-center gap-2">
        <Wrench size={18} className="text-primary" />
        <p className="font-semibold text-black">Services Provided</p>
      </div>

      <div className="mt-4 space-y-3">
        {services.length > 0 ? (
          services.map((serviceItem, index) => (
            <div
              key={`${serviceItem.title ?? "service"}-${index}`}
              className="flex items-center justify-between rounded-lg border border-gray/10 bg-secondary px-4 py-3"
            >
              <p className="text-sm text-black">{serviceItem.title ?? "-"}</p>
              <p className="text-sm font-semibold text-primary">
                {formatPrice(serviceItem.price)}
              </p>
            </div>
          ))
        ) : (
          <div className="rounded-lg border border-gray/10 bg-secondary px-4 py-3 text-sm text-gray">
            No services available
          </div>
        )}
      </div>
    </Card>
  );
}