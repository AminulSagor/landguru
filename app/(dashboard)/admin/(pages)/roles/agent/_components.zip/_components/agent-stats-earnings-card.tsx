import Card from "@/components/cards/card";
import { AgentDetails } from "@/types/admin/agent-list/details/[id]/agent-details.types";

const formatEarned = (value?: string | number | null) => {
  if (value === null || value === undefined || value === "") {
    return "-";
  }

  return String(value);
};

export default function AgentStatsEarningsCard({
  agent,
}: {
  agent: AgentDetails;
}) {
  const earned = formatEarned(agent?.stats?.totalEarned);
  const note = agent?.stats?.lastPayoutNote ?? "-";

  return (
    <Card>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs uppercase tracking-wide text-gray">
            Total Earned
          </p>
          <p className="mt-2 text-3xl font-semibold text-black">{earned}</p>
          <p className="mt-1 text-xs text-gray">{note}</p>
        </div>

        <div className="flex h-7 w-7 items-center justify-center rounded-md bg-green/10">
          <span className="text-sm font-semibold text-green">৳</span>
        </div>
      </div>
    </Card>
  );
}